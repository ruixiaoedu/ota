#!/bin/bash

echo "====== pre install is running ======"
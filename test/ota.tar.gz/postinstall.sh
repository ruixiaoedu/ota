#!/bin/bash

echo "====== post install is running ======"